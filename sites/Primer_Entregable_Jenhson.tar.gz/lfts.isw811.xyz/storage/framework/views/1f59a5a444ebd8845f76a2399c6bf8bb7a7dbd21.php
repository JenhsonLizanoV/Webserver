<!DOCTYPE html>
<title>My Blog</title>
<link rel="stylesheet" href="/app.css" />

<body>
    <?php foreach ($posts as $post) : ?>
        <article>
            <h1>
                <a href="/posts/<?= $post->slug; ?>">
                    <?= $post->title; ?>
                </a>
            </h1>

            <p>
                By <a href="/authors/<?php echo e($post->author->username); ?>"><?php echo e($post->author->name); ?></a> in <a href="/categories/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a>
            </p>


            <div>
                <?= $post->excerpt; ?>
            </div>
        </article>
    <?php endforeach; ?>
</body><?php /**PATH /home/vagrant/sites/lfts.isw811.xyz/resources/views/posts.blade.php ENDPATH**/ ?>