<!DOCTYPE html>
<title>My Blog</title>
<link rel="stylesheet" href="/app.css" />

<body>
    <article>
        <h1><?php echo $post->title; ?></h1>

        <p>
            By <a href="/authors/<?php echo e($post->author->username); ?>"><?php echo e($post->author->name); ?></a> in <a href="/categories/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->name); ?></a>
        </p>

        <div>
            <?php echo $post->body; ?>

        </div>
    </article>

    <a href="/">Go Back</a>
</body><?php /**PATH /home/vagrant/sites/lfts.isw811.xyz/resources/views/post.blade.php ENDPATH**/ ?>