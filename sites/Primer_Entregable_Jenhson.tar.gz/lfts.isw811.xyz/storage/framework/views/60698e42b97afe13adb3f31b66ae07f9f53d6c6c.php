<!DOCTYPE html>
<title>My Blog</title>
<link rel="stylesheet" href="/app.css"/>
<script src="/app.js"></script>
<body>
    <h1>Hello World!</h1>
</body><?php /**PATH /home/vagrant/sites/lfts.isw811.xyz/resources/views/welcome.blade.php ENDPATH**/ ?>